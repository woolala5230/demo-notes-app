exports.main = async function () {
  return { statusCode: 200, body: "Connected." };
};
